=== Custom Share Buttons with Floating Sidebar ===
Contributors: wpcdeveloper
Tags: responsive, social, share, buttons, responsive share buttons, responsive social share buttons, twitter, facebook, google, linkedin, pinterest, reddit, youtube, stumbleupon
Requires at least: 3.8
Tested up to: 4.7
Stable tag: 1.0

Responsive social share buttons, can be shown as a sidebar or on top/bottom of articles and posts.

== Description ==

<strong>To activate social share buttons go to settings in the admin sidebar menu, and then click "Social Share buttons". This is where you make your settings</strong>


<b>Features</b>
<ul>
	<li>Floating social share sidebar</li>
	<li>Share buttons on posts/pages</li>
	<li>Facebook share button</li>
	<li>Google Plus share button</li>
	<li>Pinterest share button</li>
	<li>Twitter share button</li>
	<li>Reddit share button</li>
	<li>Stumbleupon share button</li>
	<li>Email share button</li>
	<li>Linkedin share button</li>
	<li>Youtube share button</li>
	<li>Change background color of buttons</li>
	<li>Upload your own button images</li>
	<li>Show/Hide any button</li>
	<li>Position the buttons yourself</li>
	<li>Standard pinterest image</li>
	<li>Hide on mobile option</li>
	<li>Delay sidebar on load</li>
	<li>Choose margin top yourself</li>
	<li>Pick your own share text</li>
</ul>


1. Dowanload the plugin, unzip it and and upload plugins file to plugin (`/wp-content/plugins/`) directory

2. Activate the plugin through the Plugins menu in WordPress

3. Go to Settings and click Social Share Buttons, make your settings and enjoy.



== Installation ==

1. Dowanload the plugin, unzip it and and upload plugins file to plugin (`/wp-content/plugins/`) directory

2. Activate the plugin through the Plugins menu in WordPress

3. Go to Settings and click Social Share Buttons, make your settings and enjoy.


== Screenshots ==

1. screenshot-1.png
